package com.project.pantry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PantryApplicationTests {

	@Test
	void contextLoads() {
	}

}
