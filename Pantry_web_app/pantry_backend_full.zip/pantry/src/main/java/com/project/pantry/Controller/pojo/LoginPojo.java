package com.project.pantry.Controller.pojo;

public class LoginPojo {
	String email;
	String password;
	public String getEmail() {
		return email;
	}
	public void setMobile(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}